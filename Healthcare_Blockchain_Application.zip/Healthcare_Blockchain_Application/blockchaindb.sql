# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     blockchain1
# Server version:               5.1.73-community
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2021-01-27 16:53:05
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
# Dumping database structure for blockchain1
CREATE DATABASE IF NOT EXISTS `blockchain2` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `blockchain2`blockchain1``blockchain2``blockchain2``blockchain4``blockchain4``blockchain4``blockchain2``blockchain3``blockchain4``;
`health_care_db_new``tblinfohospital`

# Dumping structure for table blockchain4`blockchain4`.transhash
CREATE TABLE IF NOT EXISTS `transhash` (
  `TransactionID` int(11) NOT NULL AUTO_INCREMENT,
  `PlainData` longtext,
  `BlocKData` longtext,
  `PreviousHash` longtext,
  `HashBlock` longtext,
  `Current_Times` longtext,
  PRIMARY KEY (`TransactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
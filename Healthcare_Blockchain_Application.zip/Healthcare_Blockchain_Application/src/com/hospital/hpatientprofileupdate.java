package com.hospital;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Blockchain.Block;
import Blockchain.ChainConsensus;

import com.algo.HashGeneratorUtils;
import com.connection.Dbconn;

/**
 * Servlet implementation class hpatientprofileupdate
 */
@WebServlet("/hpatientprofileupdate")
public class hpatientprofileupdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String Insurance_Company;
	public static String Policy_Name;
	public static String Months;
	public static String Coverage_Msg;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public hpatientprofileupdate() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		String email = request.getParameter("email");
		String txtfirstname = request.getParameter("txtfirstname");
		String txtmiddlename = request.getParameter("txtmiddlename"), txtlastname = request
				.getParameter("txtlastname");
		String txtdd = request.getParameter("txtdd");
		// String txtmm = request.getParameter("txtmm");
		// String txtyy = request.getParameter("txtyy");
		String bod = txtdd;
		System.out.println("Date=>" + bod);
		String txtdf = request.getParameter("txtdf"), txtdfd = request
				.getParameter("txtdfd"), txtds = request
				.getParameter("txtds"), txtdsd = request.getParameter("txtdsd"), txtdt = request
				.getParameter("txtdt"), txtdtd = request
				.getParameter("txtdtd"),
				i1 = request.getParameter("i1"),
				d1 = request.getParameter("d1"),
				a1 = request.getParameter("a1"),
				i2 = request.getParameter("i2"),
				d2 = request.getParameter("d2"),
				a2 = request.getParameter("a2"),
						i3 = request.getParameter("i3"),
						d3 = request.getParameter("d3"),
						a3 = request.getParameter("a3"),
								i4 = request.getParameter("i4"),
								d4 = request.getParameter("d4"),
								a4 = request.getParameter("a4");
		
		String bill_data=i1+","+d1+","+a1+","+i2+","+d2+","+a2+","+i3+","+d3+","+a3+","+i4+","+d4+","+a4;
				
		
		
		
		
		
		Connection con;
		HttpSession session = request.getSession(true);
		String Hospitalemail = (String) session.getAttribute("hospitalname");
		// String email=(String)session.getAttribute("pemailid");

		int i = 0;
		try {
			if (txtdf.isEmpty() || txtdf.equals(null) || txtdf == null) {
				txtdf = "-";
			}
			if (txtdfd.isEmpty() || txtdfd.equals(null) || txtdfd == null) {
				txtdfd = "-";
			}
			if (txtds.isEmpty() || txtds.equals(null) || txtds == null) {
				txtds = "-";
			}
			if (txtdsd.isEmpty() || txtdsd.equals(null) || txtdsd == null) {
				txtdsd = "-";
			}
			if (txtdt.isEmpty() || txtdt.equals(null) || txtdt == null) {
				txtdt = "-";
			}
			if (txtdtd.isEmpty() || txtdtd.equals(null) || txtdtd == null) {
				txtdtd = "-";
			}
			con = Dbconn.conn();

			// String
			// sql1="update tblmasterpatient set First_Name='"+txtfirstname+"',Middle_Name='"+txtmiddlename+"',Last_Name='"+txtlastname+"',Birth_Of_Date='"+bod+"',Systolic_BP='"+txtdf+"',Dystolic_BP='"+txtdfd+"',Pulse_Pressure='"+txtds+"',Cholestrol_Data='"+txtdsd+"',Ldl='"+txtdt+"',Hdl='"+txtdtd+"' where Email_ID='"+email+"'";
			// Statement st=con.createStatement();
			// st.executeUpdate(sql1);

			String data = email + txtfirstname + txtmiddlename + txtlastname
					+ bod + txtdf + txtdfd + txtds + txtdsd + txtdt
					+ txtdtd;
			
			ChainConsensus.Consensus(data);
			String hash =Block.hash;
			Statement st0 = con.createStatement();
			String query1 = "select * from tblinfoinsurance where PatientEmail='"
					+ email + "'";
			ResultSet rs1 = st0.executeQuery(query1);
			while (rs1.next()) {
				Insurance_Company = rs1.getString("Company_Name");
				Policy_Name = rs1.getString("Policy_Name");
				Months = rs1.getString("Policy_Tenue");
				Coverage_Msg = rs1.getString("Coverage_Info");
			}
			PreparedStatement p1;
			String sql = "insert into tblinfohospital(PatientEmail,Insurance_Company,Police_Name,Months,Coverage_Msg,Hospital_Email_ID) values(?,?,?,?,?,?)";
			p1 = (PreparedStatement) con.prepareStatement(sql);
			p1.setString(1, email);
			p1.setString(2, Insurance_Company);
			p1.setString(3, Policy_Name);
			p1.setString(4, Months);
			p1.setString(5, Coverage_Msg);
			p1.setString(6, Hospitalemail);
			p1.executeUpdate();
			String txtdate = request.getParameter("txtdate");
			String txttime = request.getParameter("txttime");
			String currenttime = txtdate + " " + txttime;
			PreparedStatement p2;
			String sq2 = "insert into tblblockchain(Hospital_Email_ID,BlocKData,Current_Times) values(?,?,?)";
			p2 = (PreparedStatement) con.prepareStatement(sq2);
			p2.setString(1, Hospitalemail);
			p2.setString(2, hash);
			p2.setString(3, currenttime);
			p2.executeUpdate();

			PreparedStatement p20;
			String sq20 = "insert into tblmaster(Transcation_Hash,FromName,ToName,NonceData,PreViewHash,DiseaseFirst,DiseaseFirstDesc,DiseaseSecond,DiseaseSecondDesc,DiseaseThree,DiseaseThreeDesc,BilligInfo) values(?,?,?,?,?,?,?,?,?,?,?,?)";
			p20 = (PreparedStatement) con.prepareStatement(sq20);
			p20.setString(1, hash);
			p20.setString(2, Hospitalemail);
			p20.setString(3, email);
			p20.setString(4, String.valueOf(Block.nonce));
			p20.setString(5, Dbconn.PrevHash1);
			p20.setString(6, txtdf);
			p20.setString(7, txtdfd);
			p20.setString(8, txtds);
			p20.setString(9, txtdsd);
			p20.setString(10, txtdt);
			p20.setString(11, txtdtd);
			p20.setString(12,bill_data);
			p20.executeUpdate();

			// /

			PreparedStatement p120;
			String sq120 = "insert into tblmasterpatientnew(First_Name,Middle_Name,Last_Name,Birth_Of_Date,DiseaseFirst,DiseaseFirstDesc, DiseaseSecond, DiseaseSecondDesc, DiseaseThree,DiseaseThreeDesc,Email_ID,DateShow,BilligInfo) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			p120 = (PreparedStatement) con.prepareStatement(sq120);
			p120.setString(1, txtfirstname);
			p120.setString(2, txtmiddlename);
			p120.setString(3, txtlastname);
			p120.setString(4, bod);
			p120.setString(5, txtdf);
			p120.setString(6, txtdfd);
			p120.setString(7, txtds);
			p120.setString(8, txtdsd);
			p120.setString(9, txtdt);
			p120.setString(10, txtdtd);
			p120.setString(11, email);
			p120.setString(12, currenttime);
			p120.setString(13, bill_data);
			p120.executeUpdate();
			System.out.println("Data");
			

		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		}

		{
			pw.println("<script> alert('Update Profile Successfully');</script>");
			RequestDispatcher rd = request
					.getRequestDispatcher("/Analysis_Hospital.jsp");
			rd.include(request, response);
		}
	}
}

# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     health_care_db_new
# Server version:               5.1.73-community
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2021-03-18 11:19:31
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
# Dumping database structure for health_care_db_new
CREATE DATABASE IF NOT EXISTS `health_care_db_new` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `health_care_db_new`;


# Dumping structure for table health_care_db_new.tblblockchain
CREATE TABLE IF NOT EXISTS `tblblockchain` (
  `TransactionID` int(10) NOT NULL AUTO_INCREMENT,
  `Hospital_Email_ID` longtext,
  `BlocKData` longtext,
  `Current_Times` longtext,
  PRIMARY KEY (`TransactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblblockchain: 15 rows
/*!40000 ALTER TABLE `tblblockchain` DISABLE KEYS */;
INSERT INTO `tblblockchain` (`TransactionID`, `Hospital_Email_ID`, `BlocKData`, `Current_Times`) VALUES (1, 'admin@gmail.com', 'cd2a134d56a3dea9396bbab8642c9aee629aed19e918040964603d3b1650d576', '2020-12-16 11:01:19'), (2, 'admin@gmail.com', '2a8ea1ba2b2cbe27221566fc46bcb1c37869f8060e0e4c7fbbb0a99d003b9d38', '2020-12-16 11:03:06'), (3, 'admin@gmail.com', '79456b25f9e057ba726b84f9312adb2a9a7b50741f4489108767fd5a6b0009b4', '2020-12-16 11:56:58'), (4, 'admin@gmail.com', 'ba50242c6701a8423e41b4022db989243da43f017962c972702a435404cfc50a', '2020-12-16 11:59:31'), (5, 'admin@gmail.com', '78057dfe64b7b2bf555afe00468c4fb303c25272fd3d7f2e0e7318acb0b69770', '2020-12-16 12:00:00'), (6, 'admin@gmail.com', '00000c3a7497fe8431de0321252321eed4d3fb53ae392699ba0bf9c698480f68', '2021-03-17 15:15:11'), (7, 'admin@gmail.com', '00000b101b3695a17d88a19726dd1ac824c627ad88e334142011188d91b03981', '2021-03-17 15:17:20'), (8, 'admin@gmail.com', '000000e2315c95350fc401de1098afca85ad8aeedb4ac7b15400fa161a9fbbf8', '2021-03-17 15:19:08'), (9, 'admin@gmail.com', '00000aa5e867ee6764674a60a17885c95f0bd0d8991ab92d12275fd1bf0eb2c3', '2021-03-17 15:40:29'), (10, 'admin@gmail.com', '00000aa5e867ee6764674a60a17885c95f0bd0d8991ab92d12275fd1bf0eb2c3', '2021-03-17 15:40:29'), (11, 'admin@gmail.com', '000002a95d9ec61f944ffa757097b05f21d18576241deabcac02b6e70de6732a', '2021-03-17 15:42:47'), (12, 'admin@gmail.com', '000009854ee3d02201a04cc66444e599f24ae88ad8fdc19e527c542e824ef823', '2021-03-17 15:43:30'), (13, 'admin@gmail.com', '00000195581d167f2a1d6dab4b01744a31a51b68d96d9e34c5ca0420dce6ba27', '2021-03-17 15:45:07'), (14, 'admin@gmail.com', '0000000c5c0ddc0ceff8a686583569968aef2090fe2c46c875a4d04d86443062', '2021-03-17 15:48:11'), (15, 'admin@gmail.com', '00000924af91e31d2d4daa3710c7e214a61c25e3de944e754860d79393dffa75', '2021-03-18 10:45:29');
/*!40000 ALTER TABLE `tblblockchain` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblhospital
CREATE TABLE IF NOT EXISTS `tblhospital` (
  `ID_Patient` int(10) NOT NULL AUTO_INCREMENT,
  `Name` text,
  `Email_IDs` text,
  `Mobile_No` text,
  `Passwords` text,
  `Address` text,
  `Gender` text,
  PRIMARY KEY (`ID_Patient`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblhospital: 1 rows
/*!40000 ALTER TABLE `tblhospital` DISABLE KEYS */;
INSERT INTO `tblhospital` (`ID_Patient`, `Name`, `Email_IDs`, `Mobile_No`, `Passwords`, `Address`, `Gender`) VALUES (1, 'jitu', 'admin@gmail.com', '8888888888', '123456', '8888888888', 'Male');
/*!40000 ALTER TABLE `tblhospital` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblinfohospital
CREATE TABLE IF NOT EXISTS `tblinfohospital` (
  `I_IDs` int(10) NOT NULL AUTO_INCREMENT,
  `PatientEmail` text,
  `Insurance_Company` text,
  `Police_Name` text,
  `Months` text,
  `Coverage_Msg` text,
  `Hospital_Email_ID` text,
  KEY `I_IDs` (`I_IDs`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblinfohospital: 15 rows
/*!40000 ALTER TABLE `tblinfohospital` DISABLE KEYS */;
INSERT INTO `tblinfohospital` (`I_IDs`, `PatientEmail`, `Insurance_Company`, `Police_Name`, `Months`, `Coverage_Msg`, `Hospital_Email_ID`) VALUES (1, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (2, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (3, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (4, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (5, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (6, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (7, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (8, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (9, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (10, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (11, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (12, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (13, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (14, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com'), (15, 'om@gmail.com', 'tata', 'healthcare', '2', 'family member', 'admin@gmail.com');
/*!40000 ALTER TABLE `tblinfohospital` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblinfoinsurance
CREATE TABLE IF NOT EXISTS `tblinfoinsurance` (
  `T_ID` int(10) NOT NULL AUTO_INCREMENT,
  `PatientName` text,
  `PatientEmail` text,
  `Company_Name` text,
  `Mobile_Number` text,
  `Web_Site` text,
  `Address` text,
  `Policy_No` text,
  `Policy_Name` text,
  `Policy_Tenue` text,
  `Base_Premium` text,
  `Coverage_Info` text,
  `Policy_Amount` text,
  `Email_IDs` text,
  PRIMARY KEY (`T_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblinfoinsurance: 1 rows
/*!40000 ALTER TABLE `tblinfoinsurance` DISABLE KEYS */;
INSERT INTO `tblinfoinsurance` (`T_ID`, `PatientName`, `PatientEmail`, `Company_Name`, `Mobile_Number`, `Web_Site`, `Address`, `Policy_No`, `Policy_Name`, `Policy_Tenue`, `Base_Premium`, `Coverage_Info`, `Policy_Amount`, `Email_IDs`) VALUES (1, 'om', 'om@gmail.com', 'tata', '8888888888', 'www.tatas.com', 'pune', '10201', 'healthcare', '2', '150000', 'family member', '1500', 'raj@gmail.com');
/*!40000 ALTER TABLE `tblinfoinsurance` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblinfoinsuranceo
CREATE TABLE IF NOT EXISTS `tblinfoinsuranceo` (
  `I_IDs` int(10) NOT NULL AUTO_INCREMENT,
  `PatientName` text,
  `PatientEmail` text,
  `Insurance_Company` text,
  `Police_Name` text,
  `Months` text,
  `Coverage_Msg` text,
  KEY `I_IDs` (`I_IDs`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblinfoinsuranceo: 0 rows
/*!40000 ALTER TABLE `tblinfoinsuranceo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblinfoinsuranceo` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblinsurance
CREATE TABLE IF NOT EXISTS `tblinsurance` (
  `ID_Patient` int(10) NOT NULL AUTO_INCREMENT,
  `Name` text,
  `Email_IDs` text,
  `Mobile_No` text,
  `Passwords` text,
  `Address` text,
  `Gender` text,
  PRIMARY KEY (`ID_Patient`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblinsurance: 1 rows
/*!40000 ALTER TABLE `tblinsurance` DISABLE KEYS */;
INSERT INTO `tblinsurance` (`ID_Patient`, `Name`, `Email_IDs`, `Mobile_No`, `Passwords`, `Address`, `Gender`) VALUES (1, 'Raj', 'raj@gmail.com', '8888888888', '123456', '8888888888', 'Male');
/*!40000 ALTER TABLE `tblinsurance` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblinsurance_details
CREATE TABLE IF NOT EXISTS `tblinsurance_details` (
  `T_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Email_IDs` text,
  `Company_Name` text,
  `Mobile_Number` text,
  `Web_Site` text,
  `Address` text,
  `Policy_No` text,
  `Policy_Name` text,
  `Policy_Tenue` text,
  `Base_Premium` text,
  `Coverage_Info` text,
  `Policy_Amount` text,
  PRIMARY KEY (`T_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblinsurance_details: 1 rows
/*!40000 ALTER TABLE `tblinsurance_details` DISABLE KEYS */;
INSERT INTO `tblinsurance_details` (`T_ID`, `Email_IDs`, `Company_Name`, `Mobile_Number`, `Web_Site`, `Address`, `Policy_No`, `Policy_Name`, `Policy_Tenue`, `Base_Premium`, `Coverage_Info`, `Policy_Amount`) VALUES (1, 'raj@gmail.com', 'tata', '8888888888', 'www.tatas.com', 'pune', '10201', 'healthcare', '2', '150000', 'family member', '1500');
/*!40000 ALTER TABLE `tblinsurance_details` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblmaster
CREATE TABLE IF NOT EXISTS `tblmaster` (
  `Trans_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Transcation_Hash` text,
  `FromName` text,
  `ToName` text,
  `NonceData` text,
  `PreViewHash` text,
  `DiseaseFirst` text,
  `DiseaseSecond` text,
  `DiseaseThrees` text,
  `DiseaseFour` text,
  `DiseaseFive` text,
  `DiseaseSix` text,
  PRIMARY KEY (`Trans_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblmaster: 15 rows
/*!40000 ALTER TABLE `tblmaster` DISABLE KEYS */;
INSERT INTO `tblmaster` (`Trans_ID`, `Transcation_Hash`, `FromName`, `ToName`, `NonceData`, `PreViewHash`, `DiseaseFirst`, `DiseaseSecond`, `DiseaseThrees`, `DiseaseFour`, `DiseaseFive`, `DiseaseSix`) VALUES (1, 'cd2a134d56a3dea9396bbab8642c9aee629aed19e918040964603d3b1650d576', 'admin@gmail.com', 'om@gmail.com', '32', '0', 'aaa', '-', '-', '-', '-', '-'), (2, '2a8ea1ba2b2cbe27221566fc46bcb1c37869f8060e0e4c7fbbb0a99d003b9d38', 'admin@gmail.com', 'om@gmail.com', '64', '0', 'jbkgl', 'a', '-', '-', '-', '-'), (3, '79456b25f9e057ba726b84f9312adb2a9a7b50741f4489108767fd5a6b0009b4', 'admin@gmail.com', 'om@gmail.com', '32', '0', 'acd', '-', '-', '-', '-', '-'), (4, 'ba50242c6701a8423e41b4022db989243da43f017962c972702a435404cfc50a', 'admin@gmail.com', 'om@gmail.com', '32', '0', 'aaaa', '-', '-', '-', '-', '-'), (5, '78057dfe64b7b2bf555afe00468c4fb303c25272fd3d7f2e0e7318acb0b69770', 'admin@gmail.com', 'om@gmail.com', '64', '0', 'a', 'aab', 'aac', '-', 'aad', '-'), (6, '00000c3a7497fe8431de0321252321eed4d3fb53ae392699ba0bf9c698480f68', 'admin@gmail.com', 'om@gmail.com', '0', '0', 'aaa', '-', '-', '-', '-', '-'), (7, '00000b101b3695a17d88a19726dd1ac824c627ad88e334142011188d91b03981', 'admin@gmail.com', 'om@gmail.com', '0', '00000c3a7497fe8431de0321252321eed4d3fb53ae392699ba0bf9c698480f68', 'jbk', 'vbjh', '-', '-', '-', '-'), (8, '000000e2315c95350fc401de1098afca85ad8aeedb4ac7b15400fa161a9fbbf8', 'admin@gmail.com', 'om@gmail.com', '0', '00000b101b3695a17d88a19726dd1ac824c627ad88e334142011188d91b03981', 'nmb', 'jhvjh', 'vj', '-', '-', '-'), (9, '00000aa5e867ee6764674a60a17885c95f0bd0d8991ab92d12275fd1bf0eb2c3', 'admin@gmail.com', 'om@gmail.com', '0', '000000e2315c95350fc401de1098afca85ad8aeedb4ac7b15400fa161a9fbbf8', 'aa', 'aaa', 'aaaa', 'aaa', '-', '-'), (10, '00000aa5e867ee6764674a60a17885c95f0bd0d8991ab92d12275fd1bf0eb2c3', 'admin@gmail.com', 'om@gmail.com', '0', '000000e2315c95350fc401de1098afca85ad8aeedb4ac7b15400fa161a9fbbf8', 'aa', 'aaa', 'aaaa', 'aaa', '-', '-'), (11, '000002a95d9ec61f944ffa757097b05f21d18576241deabcac02b6e70de6732a', 'admin@gmail.com', 'om@gmail.com', '0', '0', 'aa', 'aa', 'aa', '-', '-', '-'), (12, '000009854ee3d02201a04cc66444e599f24ae88ad8fdc19e527c542e824ef823', 'admin@gmail.com', 'om@gmail.com', '0', '000002a95d9ec61f944ffa757097b05f21d18576241deabcac02b6e70de6732a', 'aa', 'aa', '-', '-', '-', '-'), (13, '00000195581d167f2a1d6dab4b01744a31a51b68d96d9e34c5ca0420dce6ba27', 'admin@gmail.com', 'om@gmail.com', '0', '000009854ee3d02201a04cc66444e599f24ae88ad8fdc19e527c542e824ef823', 'aa', 'aa', 'aa', '-', '-', '-'), (14, '0000000c5c0ddc0ceff8a686583569968aef2090fe2c46c875a4d04d86443062', 'admin@gmail.com', 'om@gmail.com', '0', '00000195581d167f2a1d6dab4b01744a31a51b68d96d9e34c5ca0420dce6ba27', 'aa', '-', '-', '-', '-', '-'), (15, '00000924af91e31d2d4daa3710c7e214a61c25e3de944e754860d79393dffa75', 'admin@gmail.com', 'om@gmail.com', '0', '0000068f2271ab6b7ddf10db741fc3d82bbb3a61be92a20b4429df54b777cece', 'dsfas', '-', '-', '-', '-', '-');
/*!40000 ALTER TABLE `tblmaster` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblmasterpatient
CREATE TABLE IF NOT EXISTS `tblmasterpatient` (
  `P_ID` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` text,
  `Middle_Name` text,
  `Last_Name` text,
  `Birth_Of_Date` text,
  `Email_ID` text,
  PRIMARY KEY (`P_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblmasterpatient: 1 rows
/*!40000 ALTER TABLE `tblmasterpatient` DISABLE KEYS */;
INSERT INTO `tblmasterpatient` (`P_ID`, `First_Name`, `Middle_Name`, `Last_Name`, `Birth_Of_Date`, `Email_ID`) VALUES (1, 'om', 'abcd', 'abc', '1991/1/1', 'om@gmail.com');
/*!40000 ALTER TABLE `tblmasterpatient` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblmasterpatientnew
CREATE TABLE IF NOT EXISTS `tblmasterpatientnew` (
  `P_ID` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` text,
  `Middle_Name` text,
  `Last_Name` text,
  `Birth_Of_Date` text,
  `DiseaseFirst` text,
  `DiseaseSecond` text,
  `DiseaseThrees` text,
  `DiseaseFour` text,
  `DiseaseFive` text,
  `DiseaseSix` text,
  `Email_ID` text,
  `DateShow` text,
  PRIMARY KEY (`P_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblmasterpatientnew: 13 rows
/*!40000 ALTER TABLE `tblmasterpatientnew` DISABLE KEYS */;
INSERT INTO `tblmasterpatientnew` (`P_ID`, `First_Name`, `Middle_Name`, `Last_Name`, `Birth_Of_Date`, `DiseaseFirst`, `DiseaseSecond`, `DiseaseThrees`, `DiseaseFour`, `DiseaseFive`, `DiseaseSix`, `Email_ID`, `DateShow`) VALUES (3, 'om', 'abcd', 'abc', '1991/1/1', '-', '-', '-', '-', '-', '-', 'om@gmail.com', '2020-12-16 11:56:58'), (4, 'om', 'abcd', 'abc', '1991/1/1', 'aaaa', '-', '-', '-', '-', '-', 'om@gmail.com', '2020-12-16 11:59:31'), (5, 'om', 'abcd', 'abc', '1991/1/1', 'a', 'aab', 'aac', '-', 'aad', '-', 'om@gmail.com', '2020-12-16 12:00:00'), (6, 'om', 'abcd', 'abc', '1991/1/1', 'aaa', '-', '-', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:15:11'), (7, 'om', 'abcd', 'abc', '1991/1/1', 'jbk', 'vbjh', '-', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:17:20'), (8, 'om', 'abcd', 'abc', '1991/1/1', 'nmb', 'jhvjh', 'vj', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:19:08'), (9, 'om', 'abcd', 'abc', '1991/1/1', 'aa', 'aaa', 'aaaa', 'aaa', '-', '-', 'om@gmail.com', '2021-03-17 15:40:29'), (10, 'om', 'abcd', 'abc', '1991/1/1', 'aa', 'aaa', 'aaaa', 'aaa', '-', '-', 'om@gmail.com', '2021-03-17 15:40:29'), (11, 'om', 'abcd', 'abc', '1991/1/1', 'aa', 'aa', 'aa', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:42:47'), (12, 'om', 'abcd', 'abc', '1991/1/1', 'aa', 'aa', '-', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:43:30'), (13, 'om', 'abcd', 'abc', '1991/1/1', 'aa', 'aa', 'aa', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:45:07'), (14, 'om', 'abcd', 'abc', '1991/1/1', 'aa', '-', '-', '-', '-', '-', 'om@gmail.com', '2021-03-17 15:48:11'), (15, 'om', 'abcd', 'abc', '1991/1/1', 'dsfas', '-', '-', '-', '-', '-', 'om@gmail.com', '2021-03-18 10:45:29');
/*!40000 ALTER TABLE `tblmasterpatientnew` ENABLE KEYS */;


# Dumping structure for table health_care_db_new.tblregister
CREATE TABLE IF NOT EXISTS `tblregister` (
  `ID_Patient` int(10) NOT NULL AUTO_INCREMENT,
  `Name` text,
  `Email_IDs` text,
  `Mobile_No` text,
  `Passwords` text,
  `Address` text,
  `Gender` text,
  `Hospital_Name` text,
  PRIMARY KEY (`ID_Patient`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table health_care_db_new.tblregister: 1 rows
/*!40000 ALTER TABLE `tblregister` DISABLE KEYS */;
INSERT INTO `tblregister` (`ID_Patient`, `Name`, `Email_IDs`, `Mobile_No`, `Passwords`, `Address`, `Gender`, `Hospital_Name`) VALUES (1, 'om', 'om@gmail.com', '8888888888', '123456', '8888888888', 'Male', 'admin@gmail.com');
/*!40000 ALTER TABLE `tblregister` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
